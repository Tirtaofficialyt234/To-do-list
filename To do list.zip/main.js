    function addTask(){
      const task = document.getElementById('task').value;
      if (!task) return;
      
      const li = document.createElement('li');
      li.innerHTML = `
       <span onclick="toggleDone(this)">${task}</span>
       <button onclick="removeTask(this)">x</button>
   `;
      document.getElementById("list").appendChild(li);
      document.getElementById("task ").value = "";
    }
    
    function toggleDone(el){
      el.classList.toggle("done");
    }
    
    function removeTask(el){
      el.parentElement.remove();
    }